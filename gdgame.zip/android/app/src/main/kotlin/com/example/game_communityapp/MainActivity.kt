package com.example.game_communityapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
